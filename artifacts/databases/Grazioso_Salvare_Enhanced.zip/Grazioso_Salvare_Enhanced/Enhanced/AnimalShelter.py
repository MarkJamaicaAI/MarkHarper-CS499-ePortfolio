import os
from pymongo import MongoClient
from pymongo.errors import ConnectionFailure
from dotenv import load_dotenv
from pathlib import Path

import logging

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)
class AnimalShelter:
    """CRUD operations for Animal collection in MongoDB."""

    def __init__(self):
        """Initialize MongoDB connection using environment variables."""

        env_path = Path(__file__).with_name(".env")
        load_dotenv(env_path)

        username = os.getenv("MONGO_USER")
        password = os.getenv("MONGO_PASS")
        host = os.getenv("MONGO_HOST", "nv-desktop-services.apporto.com")
        port = os.getenv("MONGO_PORT", "30685")

        if not username or not password:
            raise ValueError("Missing database credentials.")

        try:
            uri = f"mongodb://{username}:{password}@{host}:{port}/?authSource=AAC"

            self.client = MongoClient(uri, serverSelectionTimeoutMS=5000)
            self.client.server_info()
            logging.info("Connected to MongoDB successfully.")
            self.database = self.client["AAC"]
            self.collection = self.database["animals"]
            self.collection.create_index("animal_type")
            self.collection.create_index("breed")
            self.collection.create_index("date_of_birth")

            logging.info("Indexes created or verified.")

        except ConnectionFailure as e:
            raise ConnectionError(f"Database connection failed: {e}")

    # ---------- CREATE ----------
    def create(self, data):

        if not isinstance(data, dict):
           raise ValueError("Data must be a dictionary")

    # Required field validation
        required_fields = ["animal_id", "animal_type", "breed", "name"]

        for field in required_fields:
            if field not in data or not data[field]:
                raise ValueError(f"Missing required field: {field}")

        try:
            result = self.collection.insert_one(data)

            logging.info("Record inserted successfully.")

            return result.acknowledged

        except Exception as e:
            logging.error(f"Create failed: {e}")
            return False



    # ---------- READ ----------
    def read(self, query=None, projection=None, limit=0, skip=0):
        try:
            query = query or {}
            projection = projection or {"_id": False}

            cursor = self.collection.find(query, projection)

            if skip > 0:
                cursor = cursor.skip(skip)

            if limit > 0:
                cursor = cursor.limit(limit)

            results = list(cursor)
            logging.info(f"Read executed. Records returned: {len(results)}")
            return results

        except Exception as e:
            logging.error(f"Read failed: {e}")
            return []
    # ---------- UPDATE ----------
    def update(self, query, new_values):

        if not isinstance(new_values, dict):
            raise ValueError("Updated data must be a dictionary")

        try:
            result = self.collection.update_many(
                query,
                {"$set": new_values}
            )

            return result.modified_count

        except Exception as e:
            logging.error(f"Update failed: {e}")
            return 0

    # ---------- DELETE ----------
    def delete(self, query):

        try:
            result = self.collection.delete_many(query)
            return result.deleted_count

        except Exception as e:
            logging.error(f"Delete failed: {e}")
            return 0