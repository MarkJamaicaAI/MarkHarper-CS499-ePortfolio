from AnimalShelter import AnimalShelter

def main():
    db = AnimalShelter()

    # 1) Read test
    results = db.read(limit=2)
    print("READ (2 records):")
    print(results)

    # 2) Validation test (should fail)
    print("\nCREATE invalid record (should fail):")
    try:
        db.create({"animal_type": "Dog"})
    except Exception as e:
        print("Validation working:", e)

    # 3) Create valid record (should succeed)
    print("\nCREATE valid record:")
    ok = db.create({
        "animal_id": "10001",
        "animal_type": "Dog",
        "breed": "Lab",
        "name": "Max"
    })
    print("Insert acknowledged:", ok)

if __name__ == "__main__":
    main()