import numpy as np

class TreasureMaze:
    """
    Environment for the Treasure Hunt (pirate) maze.

    Maze encoding:
      - 1.0 = free cell
      - 0.0 = blocked cell

    State representation:
      (row, col, mode) where mode is kept for compatibility with older variants.
      The notebook's show() expects: pirate_row, pirate_col, _ = qmaze.state
    """

    def __init__(self, maze, pirate_cell=(0, 0), treasure_cell=None):
        self.maze = np.array(maze, dtype=float)
        self.nrows, self.ncols = self.maze.shape

        # Treasure defaults to bottom-right
        self.treasure_cell = treasure_cell if treasure_cell is not None else (self.nrows - 1, self.ncols - 1)

        # Rewards (tuned to common SNHU starter behavior)
        self.reward_step = -0.04
        self.reward_win = 1.0
        self.reward_lose = -1.0

        self.free_cells = self._compute_free_cells()
        self.visited = set()

        self.reset(pirate_cell)

    def _compute_free_cells(self):
        cells = [(r, c) for r in range(self.nrows) for c in range(self.ncols) if self.maze[r, c] == 1.0]
        # Keep treasure cell in free cells if it's free
        return cells

    def reset(self, pirate_cell):
        """Reset the environment to a start location."""
        if pirate_cell not in self.free_cells:
            raise ValueError(f"pirate_cell {pirate_cell} is not a free cell")

        self.state = (pirate_cell[0], pirate_cell[1], 0)
        self.visited = set()
        self.visited.add((pirate_cell[0], pirate_cell[1]))
        return self.observe()

    def observe(self):
        """
        Return the environment state as a flattened vector suitable for the network:
          - 0.0 blocked
          - 1.0 free
          - 0.5 visited (optional signal)
          - 0.3 pirate position
          - 0.9 treasure position
        Shape returned: (1, maze.size)
        """
        canvas = np.copy(self.maze)

        # visited cells (soft marking)
        for (r, c) in self.visited:
            if (r, c) != self.treasure_cell:
                canvas[r, c] = 0.6

        pr, pc, _ = self.state
        canvas[pr, pc] = 0.3
        tr, tc = self.treasure_cell
        canvas[tr, tc] = 0.9

        return canvas.reshape((1, -1))

    def valid_actions(self, cell=None):
        """
        Return list of valid action indices from the current cell (or a provided cell).
        Action encoding must match notebook:
          LEFT=0, UP=1, RIGHT=2, DOWN=3
        """
        if cell is None:
            r, c, _ = self.state
        else:
            r, c = cell

        actions = []

        # left
        if c - 1 >= 0 and self.maze[r, c - 1] == 1.0:
            actions.append(0)
        # up
        if r - 1 >= 0 and self.maze[r - 1, c] == 1.0:
            actions.append(1)
        # right
        if c + 1 < self.ncols and self.maze[r, c + 1] == 1.0:
            actions.append(2)
        # down
        if r + 1 < self.nrows and self.maze[r + 1, c] == 1.0:
            actions.append(3)

        return actions

    def act(self, action):
        """
        Apply an action and return: (envstate, reward, game_status)

        game_status in {'win', 'lose', 'not_over'}

        Lose condition (common in this project):
          - revisiting a cell too many times OR getting stuck looping.
        We'll implement a simple, reliable lose rule:
          - if the agent moves into an already-visited cell -> lose
        (This encourages learning shortest paths and matches many starter-code versions.)
        """
        r, c, mode = self.state

        # If action is invalid, treat as a step penalty and no movement
        if action not in self.valid_actions():
            reward = self.reward_step
            return self.observe(), reward, "not_over"

        # Compute new position
        nr, nc = r, c
        if action == 0:      # LEFT
            nc -= 1
        elif action == 1:    # UP
            nr -= 1
        elif action == 2:    # RIGHT
            nc += 1
        elif action == 3:    # DOWN
            nr += 1

        self.state = (nr, nc, mode)

        # Win check
        if (nr, nc) == self.treasure_cell:
            reward = self.reward_win
            return self.observe(), reward, "win"

        # Lose if revisiting
        if (nr, nc) in self.visited:
            reward = self.reward_lose
            return self.observe(), reward, "lose"

        # Normal step
        self.visited.add((nr, nc))
        reward = self.reward_step
        return self.observe(), reward, "not_over"