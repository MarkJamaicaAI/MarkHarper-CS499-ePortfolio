# CS-370
# In the pirate intelligent agent project using a Jupyter Notebook, I was tasked with creating an AI agent capable of navigating a maze to locate a treasure before the human player could reach it. The starter code provided included core files such as TreasureMaze.py, which defined the environment, GameExperience.py for managing the memory buffer, and a partially built notebook to guide the development process. My role was to implement the deep Q-learning algorithm, tune hyperparameters, and train the model. I created and modified functions such as qtrain() to facilitate training, set exploration and learning rate values, and ultimately verified the model’s performance by observing how effectively the agent learned to find the treasure across multiple episodes.

# This project helped connect concepts from the course, such as reinforcement learning, neural networks, and exploration-exploitation strategies,to real-world computer science applications. Computer scientists are problem-solvers who build and improve systems to make intelligent decisions based on data. In this case, I approached the problem by analyzing the agent’s state space, defining rewards, and iteratively testing different configurations to optimize learning. It reflects how computer scientists often use trial-and-error experimentation, backed by theory and data analysis, to solve complex challenges.

# Moreover, this work underscored the ethical responsibilities of computer scientists. When developing intelligent systems, it is crucial to consider how the agent behaves, what data it uses, and whether the system behaves transparently and fairly. As a developer, I must ensure that the agent does not unintentionally exploit bugs or produce biased outcomes, and that the system can be trusted by both end users and the organization. This mindset of ethical awareness is fundamental to building AI responsibly and ensuring its long-term benefit to society.









