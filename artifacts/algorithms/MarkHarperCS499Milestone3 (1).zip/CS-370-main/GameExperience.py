import random
import numpy as np

class GameExperience:
    """
    Stores experience tuples and produces training data for deep Q-learning.

    Each episode item is expected to be:
      [prev_envstate, action, reward, envstate, game_status]
    Where prev_envstate/envstate are shaped (1, state_size).
    """

    def __init__(self, model, max_memory=1000, discount=0.95):
        self.model = model
        self.max_memory = int(max_memory)
        self.discount = float(discount)
        self.memory = []

    def remember(self, episode):
        """Add an episode to memory; keep size under max_memory."""
        self.memory.append(episode)
        if len(self.memory) > self.max_memory:
            self.memory.pop(0)

    def get_data(self, data_size=50):
        """
        Build a mini-batch (inputs, targets) for training.

        - inputs:  (batch, state_size)
        - targets: (batch, num_actions)

        Q-target:
          target[action] = reward                      if terminal
          target[action] = reward + discount * max(Q(next_state)) otherwise
        """
        data_size = min(int(data_size), len(self.memory))
        if data_size == 0:
            # Nothing to train on yet; return empty arrays with correct shapes
            state_size = self.model.input_shape[-1]
            num_actions = self.model.output_shape[-1]
            return np.zeros((0, state_size)), np.zeros((0, num_actions))

        batch = random.sample(self.memory, data_size)

        state_size = self.model.input_shape[-1]
        num_actions = self.model.output_shape[-1]

        inputs = np.zeros((data_size, state_size))
        targets = np.zeros((data_size, num_actions))

        for i, (prev_state, action, reward, next_state, game_status) in enumerate(batch):
            # Flatten from (1, state_size) to (state_size,)
            prev_state_vec = prev_state.reshape(-1)
            next_state_vec = next_state.reshape(-1)

            inputs[i] = prev_state_vec

            # Current Q-values
            target_q = self.model.predict(prev_state, verbose=0)[0]

            # Terminal?
            terminal = (game_status == "win") or (game_status == "lose")

            if terminal:
                target_q[action] = reward
            else:
                next_q = self.model.predict(next_state, verbose=0)[0]
                target_q[action] = reward + self.discount * np.max(next_q)

            targets[i] = target_q

        return inputs, targets